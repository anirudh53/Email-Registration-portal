<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
    </head>
    <body>
        <p style="color:green;font-size:100px"  >
            WELCOME <?php echo $_GET['user'];?>
        </p>
    </body>
</html>